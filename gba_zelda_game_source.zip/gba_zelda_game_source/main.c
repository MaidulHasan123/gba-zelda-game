
#include <stdint.h>
#define REG_DISPCNT *(volatile uint16_t*)0x4000000
#define MODE3 3
#define BG2_ENABLE (1<<10)
#define VIDEO_BUFFER ((volatile uint16_t*)0x6000000)

void setPixel(int x, int y, uint16_t color) {
    VIDEO_BUFFER[y * 240 + x] = color;
}

int main(void) {
    REG_DISPCNT = MODE3 | BG2_ENABLE;
    while (1) {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 20; j++) {
                setPixel(120 + i, 80 + j, 0x001F); // Blue square (player)
            }
        }
    }
    return 0;
}
