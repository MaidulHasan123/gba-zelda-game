
#include "press_start.h"

const u16 press_start_palette[16] = { 0x001F, 0x03E0, 0x7C00 };
const u8 press_start_tiles[2048] = { 0 };
const u16 press_start_map[1024] = { 0 };
