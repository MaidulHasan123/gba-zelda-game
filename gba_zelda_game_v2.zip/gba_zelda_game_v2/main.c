#include "press_start.h"

#include <tonc.h>

extern const u16 press_start_palette[16];
extern const u8 press_start_tiles[2048];
extern const u16 press_start_map[1024];

void wait_for_key() {
    while(1) {
        key_poll();
        if (key_is_down(KEY_START)) break;
        VBlankIntrWait();
    }
}

int main() {
    REG_DISPCNT = DCNT_MODE0 | DCNT_BG0;

    // BG Setup
    REG_BG0CNT = BG_CBB(0) | BG_SBB(28) | BG_4BPP | BG_REG_32x32;

    // Load tiles, map, palette
    memcpy(pal_bg_mem, press_start_palette, 32);
    memcpy(&tile_mem[0][0], press_start_tiles, 2048);
    memcpy(se_mem[28], press_start_map, 2048);

    wait_for_key();

    // Clear screen and show solid color (game would go here)
    REG_DISPCNT = DCNT_BLANK;
    while(1);
}
