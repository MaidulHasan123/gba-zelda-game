
extern const u16 press_start_palette[16];
extern const u8 press_start_tiles[2048];
extern const u16 press_start_map[1024];
